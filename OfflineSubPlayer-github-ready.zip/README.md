# Offline SubPlayer (Android)

Pemutar video Android dengan terjemahan subtitle `.srt` otomatis secara **offline** menggunakan **Media3 ExoPlayer**, **Jetpack Compose (Material 3)**, dan **Google ML Kit Translation**.

## Fitur Utama
- Pemutaran video lokal dengan kontrol gesture (geser horizontal untuk *seek*, usap vertikal kiri untuk kecerahan, usap vertikal kanan untuk volume).
- Terjemahan subtitle `.srt` offline untuk semua pasangan bahasa yang didukung ML Kit Translation.
- Pemilihan bahasa asal & tujuan lengkap dengan pencarian, tombol tukar bahasa (*swap*), serta indikator progres terjemahan.
- Simpan hasil terjemahan ke file `.srt` baru dan muat ulang otomatis.

## Cara Build APK di GitHub Actions
1. Ekstrak seluruh isi ZIP ini dan unggah ke repositori GitHub Anda (pastikan folder `.github/workflows/` ikut terunggah).
2. Setiap `push` ke branch `main` akan otomatis menjalankan workflow **Build Offline SubPlayer APK** dan menghasilkan `OfflineSubPlayer-debug-apk` di tab **Actions**.
3. Untuk merilis versi (misalnya `v1.0.0`), jalankan:
   ```bash
   git tag v1.0.0
   git push origin v1.0.0
   ```
   Workflow **Build & Publish Release APK** akan otomatis mengompilasi `OfflineSubPlayer-v1.0.0-YYYYMMDD.apk` dan melampirkannya ke **GitHub Releases**.
