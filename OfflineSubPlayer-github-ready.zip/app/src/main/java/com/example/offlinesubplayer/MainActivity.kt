package com.example.offlinesubplayer

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.google.mlkit.nl.translate.TranslateLanguage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Locale

data class PlayerUiState(
    val videoUri: Uri? = null,
    val subtitleName: String? = null,
    val cues: List<SubtitleCue> = emptyList(),
    val activeCue: SubtitleCue? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Long = 0L,
    val durationMs: Long = 0L,
    val showControls: Boolean = true,
    val translateEnabled: Boolean = true,
    val isModelReady: Boolean = false,
    val sourceLang: String = TranslateLanguage.ENGLISH,
    val targetLang: String = TranslateLanguage.INDONESIAN,
    val translationProgress: Float? = null,
    val statusMessage: String = "Pilih video dan file .srt untuk mulai"
)

class VideoPlayerViewModel : ViewModel() {
    private val translatorManager = OfflineTranslatorManager()
    private var translationJob: Job? = null

    private val _uiState = MutableStateFlow(PlayerUiState())
    val uiState: StateFlow<PlayerUiState> = _uiState.asStateFlow()

    init {
        downloadDefaultModel()
    }

    fun downloadDefaultModel(
        sourceLang: String = _uiState.value.sourceLang,
        targetLang: String = _uiState.value.targetLang
    ) {
        viewModelScope.launch {
            _uiState.update { it.copy(statusMessage = "Menyiapkan paket terjemahan offline...") }
            runCatching {
                translatorManager.prepareModel(sourceLang, targetLang)
            }.onSuccess {
                _uiState.update {
                    it.copy(
                        isModelReady = true,
                        statusMessage = "Terjemahan offline siap (${sourceLang.uppercase()} → ${targetLang.uppercase()})"
                    )
                }
                if (_uiState.value.translateEnabled && _uiState.value.cues.isNotEmpty()) {
                    translateAllCues()
                }
            }.onFailure { err ->
                _uiState.update {
                    it.copy(
                        isModelReady = false,
                        statusMessage = "Gagal menyiapkan bahasa: ${err.localizedMessage ?: "cek koneksi saat unduh model"}"
                    )
                }
            }
        }
    }

    fun changeLanguagePair(newSourceLang: String, newTargetLang: String) {
        if (newSourceLang == _uiState.value.sourceLang && newTargetLang == _uiState.value.targetLang) return
        translationJob?.cancel()

        val clearedCues = _uiState.value.cues.map { it.copy(translatedText = null) }
        _uiState.update {
            it.copy(
                sourceLang = newSourceLang,
                targetLang = newTargetLang,
                cues = clearedCues,
                activeCue = null,
                isModelReady = false,
                translationProgress = null
            )
        }
        downloadDefaultModel(newSourceLang, newTargetLang)
    }

    fun swapLanguages() {
        val currentSource = _uiState.value.sourceLang
        val currentTarget = _uiState.value.targetLang
        if (currentSource == currentTarget) return
        changeLanguagePair(newSourceLang = currentTarget, newTargetLang = currentSource)
    }

    fun setVideoUri(uri: Uri) {
        _uiState.update { it.copy(videoUri = uri) }
    }

    fun loadSubtitles(fileName: String?, srtContent: String) {
        val parsed = SrtParser.parse(srtContent)
        _uiState.update {
            it.copy(
                subtitleName = fileName ?: "Subtitle.srt",
                cues = parsed,
                activeCue = null,
                statusMessage = "Memuat ${parsed.size} baris subtitle"
            )
        }
        if (_uiState.value.translateEnabled && _uiState.value.isModelReady) {
            translateAllCues()
        }
    }

    fun toggleAutoTranslate(enabled: Boolean) {
        _uiState.update { it.copy(translateEnabled = enabled) }
        if (enabled && _uiState.value.isModelReady) {
            translateAllCues()
        }
    }

    fun exportTranslatedSrt(context: Context, uri: Uri, fileName: String? = null) {
        viewModelScope.launch {
            val cues = _uiState.value.cues
            if (cues.isEmpty()) {
                _uiState.update { it.copy(statusMessage = "Belum ada subtitle untuk disimpan") }
                return@launch
            }
            val srtText = SrtExporter.buildSrtContent(cues, preferTranslated = true)
            SrtExporter.writeToUri(context, uri, srtText)
                .onSuccess {
                    val savedContent = context.contentResolver
                        .openInputStream(uri)
                        ?.bufferedReader()
                        ?.use { it.readText() }
                        ?: srtText
                    loadSubtitles(
                        fileName = fileName ?: uri.lastPathSegment ?: "terjemahan.srt",
                        srtContent = savedContent
                    )
                    _uiState.update {
                        it.copy(statusMessage = "File .srt disimpan & dimuat ulang")
                    }
                }
                .onFailure { err ->
                    _uiState.update {
                        it.copy(statusMessage = "Gagal menyimpan .srt: ${err.localizedMessage ?: "error"}")
                    }
                }
        }
    }

    private fun translateAllCues() {
        translationJob?.cancel()
        translationJob = viewModelScope.launch {
            val currentList = _uiState.value.cues.toMutableList()
            if (currentList.isEmpty()) {
                _uiState.update { it.copy(translationProgress = null) }
                return@launch
            }

            _uiState.update { it.copy(translationProgress = 0f) }

            for (i in currentList.indices) {
                val cue = currentList[i]
                val updatedCue = if (cue.translatedText == null) {
                    cue.copy(translatedText = translatorManager.translateText(cue.originalText))
                } else {
                    cue
                }
                currentList[i] = updatedCue

                val progress = (i + 1).toFloat() / currentList.size.toFloat()
                if (i % 3 == 0 || i == currentList.lastIndex) {
                    _uiState.update {
                        it.copy(
                            cues = currentList.toList(),
                            translationProgress = progress,
                            statusMessage = "Menerjemahkan subtitle offline... ${(progress * 100).toInt()}%"
                        )
                    }
                }
            }

            _uiState.update {
                it.copy(
                    translationProgress = null,
                    statusMessage = "Terjemahan offline selesai (${it.sourceLang.uppercase()} → ${it.targetLang.uppercase()})"
                )
            }
        }
    }

    fun onPlaybackTick(positionMs: Long, durationMs: Long, isPlaying: Boolean) {
        val cue = _uiState.value.cues.firstOrNull { positionMs in it.startMs..it.endMs }
        _uiState.update {
            it.copy(
                currentPositionMs = positionMs,
                durationMs = durationMs.coerceAtLeast(0L),
                isPlaying = isPlaying,
                activeCue = cue
            )
        }
    }

    fun toggleControls() {
        _uiState.update { it.copy(showControls = !it.showControls) }
    }

    override fun onCleared() {
        translationJob?.cancel()
        translatorManager.release()
        super.onCleared()
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF7DD3FC),
                    surface = Color(0xFF090D16),
                    background = Color(0xFF090D16)
                )
            ) {
                OfflineSubtitlePlayerScreen()
            }
        }
    }
}

@Composable
fun LanguagePickerDialog(
    title: String,
    selectedCode: String,
    onDismiss: () -> Unit,
    onSelect: (String) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(query) {
        if (query.isBlank()) LanguageCatalog.allLanguages
        else LanguageCatalog.allLanguages.filter {
            it.label.contains(query, ignoreCase = true) || it.code.contains(query, ignoreCase = true)
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Cari bahasa atau kode...") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(10.dp))
                LazyColumn(
                    modifier = Modifier.heightIn(max = 320.dp)
                ) {
                    items(filtered.size) { idx ->
                        val item = filtered[idx]
                        val isSelected = item.code == selectedCode
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                                    else Color.Transparent
                                )
                                .clickable {
                                    onSelect(item.code)
                                    onDismiss()
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.label,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            if (isSelected) {
                                Icon(Icons.Rounded.Check, contentDescription = null)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Tutup") }
        }
    )
}

@Composable
fun OfflineSubtitlePlayerScreen(vm: VideoPlayerViewModel = viewModel()) {
    val context = LocalContext.current
    val activity = context as? Activity
    val audioManager = remember { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    val state by vm.uiState.collectAsState()

    var pickingSource by remember { mutableStateOf(false) }
    var pickingTarget by remember { mutableStateOf(false) }
    var suggestedExportName by remember { mutableStateOf("subtitle_id.srt") }

    var seekPreviewMs by remember { mutableStateOf<Long?>(null) }
    var brightnessLevel by remember { mutableFloatStateOf(0.7f) }
    var volumePercent by remember { mutableIntStateOf(50) }
    var activeGestureLabel by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(activity) {
        val currentWinBrightness = activity?.window?.attributes?.screenBrightness ?: -1f
        if (currentWinBrightness >= 0f) {
            brightnessLevel = currentWinBrightness.coerceIn(0.08f, 1.0f)
        } else {
            val sysBrightness = runCatching {
                Settings.System.getInt(
                    context.contentResolver,
                    Settings.System.SCREEN_BRIGHTNESS
                )
            }.getOrDefault(180)
            brightnessLevel = (sysBrightness / 255f).coerceIn(0.08f, 1.0f)
        }
    }

    val exoPlayer = remember {
        ExoPlayer.Builder(context).build().apply {
            playWhenReady = true
        }
    }

    DisposableEffect(exoPlayer) {
        onDispose { exoPlayer.release() }
    }

    LaunchedEffect(state.videoUri) {
        state.videoUri?.let { uri ->
            exoPlayer.setMediaItem(MediaItem.fromUri(uri))
            exoPlayer.prepare()
            exoPlayer.play()
        }
    }

    LaunchedEffect(exoPlayer) {
        while (true) {
            vm.onPlaybackTick(
                positionMs = exoPlayer.currentPosition,
                durationMs = exoPlayer.duration,
                isPlaying = exoPlayer.isPlaying
            )
            delay(150L)
        }
    }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let { vm.setVideoUri(it) }
    }

    val subtitlePicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            val content = context.contentResolver.openInputStream(it)?.bufferedReader()?.use { r -> r.readText() }
            if (!content.isNullOrBlank()) {
                vm.loadSubtitles(it.lastPathSegment, content)
            }
        }
    }

    val saveSubtitleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/x-subrip")
    ) { uri ->
        uri?.let { vm.exportTranslatedSrt(context, it, suggestedExportName) }
    }

    if (pickingSource) {
        LanguagePickerDialog(
            title = "Pilih Bahasa Asal",
            selectedCode = state.sourceLang,
            onDismiss = { pickingSource = false },
            onSelect = { code -> vm.changeLanguagePair(code, state.targetLang) }
        )
    }

    if (pickingTarget) {
        LanguagePickerDialog(
            title = "Pilih Bahasa Tujuan",
            selectedCode = state.targetLang,
            onDismiss = { pickingTarget = false },
            onSelect = { code -> vm.changeLanguagePair(state.sourceLang, code) }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF090D16))
            .clickable { vm.toggleControls() }
            .pointerInput(state.durationMs) {
                var accumulatedSeekDeltaMs = 0L
                detectHorizontalDragGestures(
                    onDragStart = {
                        accumulatedSeekDeltaMs = 0L
                        seekPreviewMs = exoPlayer.currentPosition
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        if (state.durationMs > 0L) {
                            accumulatedSeekDeltaMs += (dragAmount * 100f).toLong()
                            val target = (exoPlayer.currentPosition + accumulatedSeekDeltaMs)
                                .coerceIn(0L, state.durationMs)
                            seekPreviewMs = target
                        }
                    },
                    onDragEnd = {
                        seekPreviewMs?.let { target -> exoPlayer.seekTo(target) }
                        seekPreviewMs = null
                    },
                    onDragCancel = {
                        seekPreviewMs = null
                    }
                )
            }
    ) {
        Row(modifier = Modifier.fillMaxSize()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { change, dragAmount ->
                                change.consume()
                                val delta = -dragAmount / 600f
                                val next = (brightnessLevel + delta).coerceIn(0.08f, 1.0f)
                                brightnessLevel = next
                                activity?.window?.let { win ->
                                    val params = win.attributes
                                    params.screenBrightness = next
                                    win.attributes = params
                                }
                                activeGestureLabel = "Kecerahan ${(next * 100).toInt()}%"
                            },
                            onDragEnd = { activeGestureLabel = null },
                            onDragCancel = { activeGestureLabel = null }
                        )
                    }
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .pointerInput(Unit) {
                        detectVerticalDragGestures(
                            onVerticalDrag = { change, dragAmount ->
                                change.consume()
                                val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                val stepDelta = (-dragAmount / 90f).toInt()
                                if (stepDelta != 0) {
                                    val nextVol = (curVol + stepDelta).coerceIn(0, maxVol)
                                    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, nextVol, 0)
                                    volumePercent = ((nextVol.toFloat() / maxVol.toFloat()) * 100f).toInt()
                                } else {
                                    volumePercent = ((curVol.toFloat() / maxVol.toFloat()) * 100f).toInt()
                                }
                                activeGestureLabel = "Volume $volumePercent%"
                            },
                            onDragEnd = { activeGestureLabel = null },
                            onDragCancel = { activeGestureLabel = null }
                        )
                    }
            )
        }

        if (state.videoUri != null) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        player = exoPlayer
                        useController = false
                    }
                },
                update = { it.player = exoPlayer },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Rounded.OndemandVideo,
                    contentDescription = null,
                    tint = Color(0xFF7DD3FC),
                    modifier = Modifier.size(64.dp)
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    text = "Offline SubPlayer",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    text = state.statusMessage,
                    color = Color.White.copy(alpha = 0.72f),
                    textAlign = TextAlign.Center
                )
            }
        }

        val badgeText = seekPreviewMs?.let { "Seek → ${formatTime(it)}" } ?: activeGestureLabel
        if (badgeText != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.Center)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.8f))
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Text(
                    text = badgeText,
                    color = Color(0xFF7DD3FC),
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        AnimatedVisibility(
            visible = state.showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Black.copy(alpha = 0.8f), Color.Transparent)
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Offline SubPlayer",
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp
                        )
                        Text(
                            text = state.statusMessage,
                            color = Color(0xFF7DD3FC),
                            fontSize = 12.sp
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Auto", color = Color.White, fontSize = 12.sp)
                        Spacer(Modifier.width(6.dp))
                        Switch(
                            checked = state.translateEnabled,
                            onCheckedChange = { vm.toggleAutoTranslate(it) }
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = { pickingSource = true },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = LanguageCatalog.findLabel(state.sourceLang),
                            color = Color.White,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }

                    IconButton(
                        onClick = { vm.swapLanguages() },
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.14f))
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.SwapHoriz,
                            contentDescription = "Tukar Bahasa",
                            tint = Color(0xFF7DD3FC)
                        )
                    }

                    OutlinedButton(
                        onClick = { pickingTarget = true },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = LanguageCatalog.findLabel(state.targetLang),
                            color = Color.White,
                            fontSize = 12.sp,
                            maxLines = 1
                        )
                    }
                }

                state.translationProgress?.let { progress ->
                    Spacer(Modifier.height(8.dp))
                    LinearProgressIndicator(
                        progress = { progress.coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(99.dp)),
                        color = Color(0xFF7DD3FC),
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )
                }
            }
        }

        state.activeCue?.let { cue ->
            val displayText = if (state.translateEnabled && !cue.translatedText.isNullOrBlank()) {
                cue.translatedText
            } else {
                cue.originalText
            }
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(
                        bottom = if (state.showControls) 124.dp else 36.dp,
                        start = 24.dp,
                        end = 24.dp
                    )
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black.copy(alpha = 0.72f))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(
                    text = displayText,
                    color = Color.White,
                    fontSize = 16.sp,
                    lineHeight = 22.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }

        AnimatedVisibility(
            visible = state.showControls,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                if (state.durationMs > 0L) {
                    Slider(
                        value = (state.currentPositionMs.toFloat() / state.durationMs.toFloat()).coerceIn(0f, 1f),
                        onValueChange = { frac ->
                            exoPlayer.seekTo((frac * state.durationMs).toLong())
                        }
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatTime(state.currentPositionMs), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        Text(formatTime(state.durationMs), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                }

                Spacer(Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilledTonalButton(onClick = { videoPicker.launch(arrayOf("video/*")) }) {
                        Icon(Icons.Rounded.VideoFile, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Video", fontSize = 12.sp)
                    }

                    FilledTonalButton(onClick = { subtitlePicker.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Rounded.Subtitles, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("SRT", fontSize = 12.sp)
                    }

                    IconButton(
                        onClick = {
                            if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
                        },
                        modifier = Modifier
                            .size(50.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7DD3FC))
                    ) {
                        Icon(
                            imageVector = if (state.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = Color(0xFF090D16),
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    FilledTonalButton(
                        enabled = state.cues.isNotEmpty(),
                        onClick = {
                            val baseName = (state.subtitleName ?: "subtitle")
                                .substringBeforeLast(".")
                            val fileName = "${baseName}_${state.targetLang}.srt"
                            suggestedExportName = fileName
                            saveSubtitleLauncher.launch(fileName)
                        }
                    ) {
                        Icon(Icons.Rounded.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Simpan", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSec = (ms / 1000L).coerceAtLeast(0L)
    val min = totalSec / 60L
    val sec = totalSec % 60L
    return String.format(Locale.US, "%02d:%02d", min, sec)
}
